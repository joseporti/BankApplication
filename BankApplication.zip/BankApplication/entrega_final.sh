
#!/bin/bash

set -e

echo "========== PREPARANDO ENTREGA FINAL =========="

mkdir -p entrega/jars

# Copiar codigo fuente y configuraciones
cp -r account client entrega/

# Eliminar archivos temporales de compilacion
rm -rf entrega/account/target
rm -rf entrega/client/target

# Copiar documentacion
cp README.md entrega/
cp collection_bank_postman.json entrega/

# Copiar JAR ejecutable de cada microservicio
find account/target -maxdepth 1 -name "*.jar" \
    ! -name "*.jar.original" \
    ! -name "*sources.jar" \
    -exec cp {} entrega/jars/account.jar \;

find client/target -maxdepth 1 -name "*.jar" \
    ! -name "*.jar.original" \
    ! -name "*sources.jar" \
    -exec cp {} entrega/jars/client.jar \;

# Comprobar archivos obligatorios
test -s entrega/jars/account.jar
test -s entrega/jars/client.jar

# Eliminar posibles configuraciones locales
find entrega -type d \( -name ".git" -o -name ".idea" -o -name ".vscode" \) -prune -exec rm -rf {} +
find entrega -type f -name ".env" -delete

# Comprimir
zip -qr BankApplication_Entrega_Final.zip entrega

echo ""
echo "========== VERIFICANDO ZIP =========="
unzip -t BankApplication_Entrega_Final.zip | tail -1

echo ""
ls -lh BankApplication_Entrega_Final.zip
ls -lh entrega/jars/

echo ""
echo "ENTREGA FINAL PREPARADA"
