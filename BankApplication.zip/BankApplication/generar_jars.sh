
#!/bin/bash

set -e

echo "========== GENERANDO ACCOUNT =========="
mvn -f account/pom.xml clean package -DskipTests

echo ""
echo "========== GENERANDO CLIENT =========="
mvn -f client/pom.xml clean package -DskipTests

echo ""
echo "========== ARCHIVOS JAR GENERADOS =========="
find account/target client/target -maxdepth 1 \
    -type f -name "*.jar" -exec ls -lh {} \;

echo ""
echo "GENERACION FINALIZADA"
