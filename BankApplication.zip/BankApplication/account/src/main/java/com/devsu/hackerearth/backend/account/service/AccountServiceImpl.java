package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(
            AccountRepository accountRepository) {

        this.accountRepository = accountRepository;
    }

    private AccountDto toDto(Account account) {

        return new AccountDto(
            account.getId(),
            account.getNumber(),
            account.getType(),
            account.getInitialAmount(),
            account.isActive(),
            account.getClientId()
        );
    }

    private Account getEntity(Long id) {

        return accountRepository.findById(id)
            .orElseThrow(() ->
                new IllegalArgumentException(
                    "Cuenta no encontrada: " + id
                )
            );
    }

    @Override
    public List<AccountDto> getAll() {

        return accountRepository.findAll()
            .stream()
            .map(this::toDto)
            .collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        return toDto(getEntity(id));
    }

    @Override
    @Transactional
    public AccountDto create(AccountDto dto) {

        Account account = new Account();

        account.setNumber(dto.getNumber());
        account.setType(dto.getType());
        account.setInitialAmount(dto.getInitialAmount());
        account.setActive(dto.isActive());
        account.setClientId(dto.getClientId());

        return toDto(accountRepository.save(account));
    }

    @Override
    @Transactional
    public AccountDto update(AccountDto dto) {

        Account account = getEntity(dto.getId());

        account.setNumber(dto.getNumber());
        account.setType(dto.getType());
        account.setInitialAmount(dto.getInitialAmount());
        account.setActive(dto.isActive());
        account.setClientId(dto.getClientId());

        return toDto(accountRepository.save(account));
    }

    @Override
    @Transactional
    public AccountDto partialUpdate(
            Long id,
            PartialAccountDto dto) {

        Account account = getEntity(id);

        account.setActive(dto.isActive());

        return toDto(accountRepository.save(account));
    }

    @Override
    @Transactional
    public void deleteById(Long id) {

        Account account = getEntity(id);

        accountRepository.delete(account);
    }
}