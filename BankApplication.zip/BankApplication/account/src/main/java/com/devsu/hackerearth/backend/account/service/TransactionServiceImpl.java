package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.integration.ClientRestService;
import com.devsu.hackerearth.backend.account.model.dto.ClientResponseDto;

@Service
public class TransactionServiceImpl implements TransactionService {

        private final TransactionRepository transactionRepository;
        private final AccountRepository accountRepository;
        private final ClientRestService clientRestService;

        public TransactionServiceImpl(
                        TransactionRepository transactionRepository,
                        AccountRepository accountRepository,
                        ClientRestService clientRestService) {

                this.transactionRepository = transactionRepository;
                this.accountRepository = accountRepository;
                this.clientRestService = clientRestService;
        }

        private TransactionDto toDto(Transaction transaction) {

                return new TransactionDto(
                                transaction.getId(),
                                transaction.getDate(),
                                transaction.getType(),
                                transaction.getAmount(),
                                transaction.getBalance(),
                                transaction.getAccountId());
        }

        // Obtener todos los movimientos

        @Override
        public List<TransactionDto> getAll() {

                return transactionRepository.findAll()
                                .stream()
                                .map(this::toDto)
                                .collect(Collectors.toList());
        }

        // Obtener movimiento por ID

        @Override
        public TransactionDto getById(Long id) {

                Transaction transaction = transactionRepository
                                .findById(id)
                                .orElseThrow(() -> new IllegalArgumentException(
                                                "Movimiento no encontrado: " + id));

                return toDto(transaction);
        }

        // Registrar deposito o retiro

        @Override
        @Transactional
        public TransactionDto create(TransactionDto dto) {

                if (dto == null || dto.getAccountId() == null) {
                        throw new IllegalArgumentException("Cuenta requerida");
                }

                Account account = accountRepository
                                .findByIdForUpdate(dto.getAccountId())
                                .orElseThrow(() -> new IllegalArgumentException(
                                                "Cuenta no encontrada"));

                if (!account.isActive()) {
                        throw new IllegalArgumentException(
                                        "Cuenta inactiva");
                }

                double amount = dto.getAmount();

                if (!Double.isFinite(amount) || amount == 0) {
                        throw new IllegalArgumentException(
                                        "Monto invalido");
                }

                Transaction last = transactionRepository
                                .findTopByAccountIdOrderByDateDescIdDesc(
                                                account.getId());

                double balance = last == null
                                ? account.getInitialAmount()
                                : last.getBalance();

                double newBalance = balance + amount;

                if (newBalance < 0) {
                        throw new IllegalArgumentException(
                                        "Saldo no disponible");
                }

                Transaction transaction = new Transaction();

                transaction.setDate(new Date());

                transaction.setType(
                                amount > 0 ? "Deposito" : "Retiro");

                transaction.setAmount(amount);
                transaction.setBalance(newBalance);
                transaction.setAccountId(account.getId());

                return toDto(
                                transactionRepository.save(transaction));
        }

        // Obtener ultimo movimiento por cuenta

        @Override
        public TransactionDto getLastByAccountId(Long accountId) {

                Transaction transaction = transactionRepository
                                .findTopByAccountIdOrderByDateDescIdDesc(accountId);

                if (transaction == null) {
                        return null;
                }

                return toDto(transaction);
        }

        // Generar reporte bancario

        @Override
        public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(
                        Long clientId,
                        Date dateTransactionStart,
                        Date dateTransactionEnd) {

                if (clientId == null ||
                                dateTransactionStart == null ||
                                dateTransactionEnd == null) {

                        throw new IllegalArgumentException(
                                        "Parametros requeridos");
                }

                Calendar calendar = Calendar.getInstance();
                calendar.setTime(dateTransactionEnd);
                calendar.add(Calendar.DAY_OF_MONTH, 1);

                Date endExclusive = calendar.getTime();

                if (!dateTransactionStart.before(endExclusive)) {
                        throw new IllegalArgumentException(
                                        "Rango de fechas invalido");
                }

                ClientResponseDto client = clientRestService.getClientById(clientId);

                if (client == null) {
                        throw new IllegalArgumentException(
                                        "Cliente no encontrado: " + clientId);
                }

                String clientName = client.getName();

                List<BankStatementDto> report = new ArrayList<>();

                List<Account> accounts = accountRepository.findAll()
                                .stream()
                                .filter(a -> clientId.equals(a.getClientId()))
                                .collect(Collectors.toList());

                for (Account account : accounts) {

                        List<Transaction> transactions = transactionRepository
                                        .findByAccountIdAndDateBetweenOrderByDateAscIdAsc(
                                                        account.getId(),
                                                        dateTransactionStart,
                                                        new Date(endExclusive.getTime() - 1));

                        for (Transaction transaction : transactions) {

                                BankStatementDto statement = new BankStatementDto(
                                                transaction.getDate(),
                                                clientName,
                                                account.getNumber(),
                                                account.getType(),
                                                account.getInitialAmount(),
                                                account.isActive(),
                                                transaction.getType(),
                                                transaction.getAmount(),
                                                transaction.getBalance());

                                report.add(statement);
                        }
                }

                return report;
        }

        @Override
        public TransactionDto update(Long id, TransactionDto dto) {

                getById(id);

                throw new UnsupportedOperationException(
                                "No se permite modificar movimientos contabilizados. Registre una transaccion compensatoria.");
        }

        @Override
        public TransactionDto partialUpdate(Long id, TransactionDto dto) {

                getById(id);

                throw new UnsupportedOperationException(
                                "No se permite modificar movimientos contabilizados. Registre una transaccion compensatoria.");
        }

        @Override
        public void delete(Long id) {

                getById(id);

                throw new UnsupportedOperationException(
                                "No se permite eliminar movimientos contabilizados. Registre una transaccion compensatoria.");
        }
}