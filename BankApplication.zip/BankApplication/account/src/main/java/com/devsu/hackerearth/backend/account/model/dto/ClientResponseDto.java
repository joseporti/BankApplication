
package com.devsu.hackerearth.backend.account.model.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ClientResponseDto {

    private Long id;
    private String name;
    private String dni;
    private boolean isActive;

}
