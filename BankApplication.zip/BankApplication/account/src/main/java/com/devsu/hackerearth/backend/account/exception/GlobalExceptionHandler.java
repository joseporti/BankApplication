package com.devsu.hackerearth.backend.account.exception;

import java.util.Collections;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

        @ExceptionHandler(IllegalArgumentException.class)
        public ResponseEntity<Map<String, String>> handle(
                        IllegalArgumentException ex) {

                HttpStatus status = ex.getMessage() != null
                                && (ex.getMessage().startsWith("Cuenta no encontrada")
                                                || ex.getMessage().startsWith("Movimiento no encontrado"))
                                                                ? HttpStatus.NOT_FOUND
                                                                : HttpStatus.BAD_REQUEST;

                return ResponseEntity.status(status).body(
                                Collections.singletonMap("message", ex.getMessage()));
        }

        @ExceptionHandler(UnsupportedOperationException.class)
        public ResponseEntity<Map<String, String>> handleUnsupportedOperation(
                        UnsupportedOperationException ex) {

                return ResponseEntity.status(HttpStatus.CONFLICT).body(
                                Collections.singletonMap("message", ex.getMessage()));
        }
}