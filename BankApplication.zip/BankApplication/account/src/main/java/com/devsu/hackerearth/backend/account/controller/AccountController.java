package com.devsu.hackerearth.backend.account.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.service.AccountService;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

	private final AccountService accountService;

	public AccountController(AccountService accountService) {
		this.accountService = accountService;
	}

	@GetMapping
	public ResponseEntity<List<AccountDto>> getAll() {
		return ResponseEntity.ok(accountService.getAll());
	}

	@GetMapping("/{id}")
	public ResponseEntity<AccountDto> get(@PathVariable Long id) {
		AccountDto result = accountService.getById(id);
		if (result == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(result);
	}

	@PostMapping
	public ResponseEntity<AccountDto> create(@RequestBody AccountDto accountDto) {
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(accountService.create(accountDto));
	}

	/*
	 * @PutMapping("/{id}")
	 * public ResponseEntity<AccountDto> update(
	 * 
	 * @PathVariable Long id,
	 * 
	 * @RequestBody AccountDto accountDto) {
	 * 
	 * accountDto.setId(id);
	 * 
	 * AccountDto updated = accountService.update(accountDto);
	 * 
	 * if (updated == null) {
	 * return ResponseEntity.notFound().build();
	 * }
	 * 
	 * return ResponseEntity.ok(updated);
	 * }
	 */

	/*
	 * @PutMapping("/{id}")
	 * public ResponseEntity<AccountDto> update(
	 * 
	 * @PathVariable Long id,
	 * 
	 * @RequestBody AccountDto accountDto) {
	 * 
	 * AccountDto updated = accountService.update(accountDto);
	 * 
	 * if (updated == null) {
	 * return ResponseEntity.notFound().build();
	 * }
	 * 
	 * return ResponseEntity.ok(updated);
	 * }
	 */

	@PutMapping("/{id}")
	public ResponseEntity<AccountDto> update(
			@PathVariable Long id,
			@RequestBody AccountDto accountDto) {

		accountDto.setId(id);

		AccountDto updated = accountService.update(accountDto);

		if (updated == null) {
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(updated);
	}

	@PatchMapping("/{id}")
	public ResponseEntity<AccountDto> partialUpdate(
			@PathVariable Long id,
			@RequestBody PartialAccountDto partialAccountDto) {
		AccountDto result = accountService.partialUpdate(id, partialAccountDto);
		if (result == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(result);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		AccountDto existing = accountService.getById(id);
		if (existing == null) {
			return ResponseEntity.notFound().build();
		}
		accountService.deleteById(id);
		return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<Void> handleNotFound(IllegalArgumentException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
}
