
package com.devsu.hackerearth.backend.account.integration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.devsu.hackerearth.backend.account.model.dto.ClientResponseDto;

@Service
public class ClientRestService {

    private final RestTemplate restTemplate;

    @Value("${client.service.url}")
    private String clientServiceUrl;

    public ClientRestService() {
        this.restTemplate = new RestTemplate();
    }

    public ClientResponseDto getClientById(Long clientId) {

        String url = clientServiceUrl
                + "/api/clients/"
                + clientId;

        ResponseEntity<ClientResponseDto> response = restTemplate.getForEntity(
                url,
                ClientResponseDto.class);

        return response.getBody();
    }
}
