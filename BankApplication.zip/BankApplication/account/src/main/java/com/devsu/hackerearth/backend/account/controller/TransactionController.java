package com.devsu.hackerearth.backend.account.controller;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.TransactionService;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

	private final TransactionService transactionService;

	public TransactionController(
			TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	@GetMapping
	public ResponseEntity<List<TransactionDto>> getAll() {

		return ResponseEntity.ok(
				transactionService.getAll());
	}

	@GetMapping("/{id}")
	public ResponseEntity<TransactionDto> get(
			@PathVariable Long id) {

		TransactionDto result = transactionService.getById(id);

		if (result == null) {
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(result);
	}

	@PostMapping
	public ResponseEntity<TransactionDto> create(
			@RequestBody TransactionDto transactionDto) {

		return ResponseEntity.status(201).body(
				transactionService.create(transactionDto));
	}

	@GetMapping("/clients/{clientId}/report")
	public ResponseEntity<List<BankStatementDto>> report(

			@PathVariable Long clientId,

			@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTransactionStart,

			@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTransactionEnd) {

		return ResponseEntity.ok(
				transactionService
						.getAllByAccountClientIdAndDateBetween(
								clientId,
								dateTransactionStart,
								dateTransactionEnd));
	}

	@PutMapping("/{id}")
	public ResponseEntity<TransactionDto> update(
			@PathVariable Long id,
			@RequestBody TransactionDto dto) {

		return ResponseEntity.ok(
				transactionService.update(id, dto));
	}

	@PatchMapping("/{id}")
	public ResponseEntity<TransactionDto> partialUpdate(
			@PathVariable Long id,
			@RequestBody TransactionDto dto) {

		return ResponseEntity.ok(
				transactionService.partialUpdate(id, dto));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> delete(
			@PathVariable Long id) {

		transactionService.delete(id);

		return ResponseEntity.noContent().build();
	}
}