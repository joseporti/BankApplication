
package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.AccountService;
import com.devsu.hackerearth.backend.account.service.TransactionService;
import org.springframework.test.context.ActiveProfiles;
@ActiveProfiles("test")
@SpringBootTest
public class TransactionIntegrationTest {

    @Autowired
    private AccountService accountService;

    @Autowired
    private TransactionService transactionService;

    @Test
    void testDepositoRetiroYSaldoInsuficiente() {

        // 1. Crear cuenta con saldo inicial de 1000
        AccountDto account = accountService.create(
                new AccountDto(
                        null,
                        "CTA-TEST-001",
                        "Ahorros",
                        1000.0,
                        true,
                        1L));

        assertNotNull(account.getId());

        // 2. Registrar deposito de 500
        TransactionDto deposito = transactionService.create(
                new TransactionDto(
                        null,
                        null,
                        "Deposito",
                        500.0,
                        0.0,
                        account.getId()));

        assertEquals(1500.0, deposito.getBalance(), 0.001);

        // 3. Registrar retiro de 200
        TransactionDto retiro = transactionService.create(
                new TransactionDto(
                        null,
                        null,
                        "Retiro",
                        -200.0,
                        0.0,
                        account.getId()));

        assertEquals(1300.0, retiro.getBalance(), 0.001);

        // 4. Intentar retirar 2000
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> transactionService.create(
                        new TransactionDto(
                                null,
                                null,
                                "Retiro",
                                -2000.0,
                                0.0,
                                account.getId())));

        assertEquals(
                "Saldo no disponible",
                exception.getMessage());

        // 5. Verificar que el saldo no cambio
        TransactionDto ultimoMovimiento = transactionService.getLastByAccountId(account.getId());

        assertNotNull(ultimoMovimiento);

        assertEquals(
                1300.0,
                ultimoMovimiento.getBalance(),
                0.001);
    }
}
