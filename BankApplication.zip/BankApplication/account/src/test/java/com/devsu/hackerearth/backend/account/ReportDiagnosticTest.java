
package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.devsu.hackerearth.backend.account.integration.ClientRestService;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientResponseDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.service.TransactionServiceImpl;

public class ReportDiagnosticTest {

    @Test
    void diagnosticoReporteTest() {

        AccountRepository accountRepository = mock(AccountRepository.class);

        TransactionRepository transactionRepository = mock(TransactionRepository.class);

        ClientRestService clientRestService = mock(ClientRestService.class);

        TransactionServiceImpl service = new TransactionServiceImpl(
                transactionRepository,
                accountRepository,
                clientRestService);

        Long clientId = 1L;
        Long accountId = 1L;

        ClientResponseDto client = new ClientResponseDto();
        client.setId(clientId);
        client.setName("client");
        client.setActive(true);

        Account account = new Account();
        account.setId(accountId);
        account.setClientId(clientId);
        account.setNumber("accountNumber");
        account.setType("accountType");
        account.setInitialAmount(10.0);
        account.setActive(true);

        Date date = new Date();

        Transaction first = new Transaction();
        first.setId(1L);
        first.setAccountId(accountId);
        first.setDate(date);
        first.setType("transactionType");
        first.setAmount(10.0);
        first.setBalance(15.0);

        Transaction second = new Transaction();
        second.setId(2L);
        second.setAccountId(accountId);
        second.setDate(date);
        second.setType("transactionType");
        second.setAmount(5.0);
        second.setBalance(20.0);

        when(clientRestService.getClientById(clientId))
                .thenReturn(client);

        when(accountRepository.findAll())
                .thenReturn(Arrays.asList(account));

        when(transactionRepository
                .findByAccountIdAndDateBetweenOrderByDateAscIdAsc(
                        eq(accountId),
                        any(Date.class),
                        any(Date.class)))
                .thenReturn(Arrays.asList(first, second));

        List<BankStatementDto> report = service.getAllByAccountClientIdAndDateBetween(
                clientId,
                date,
                date);

        assertEquals(2, report.size());

        assertEquals(10.0, report.get(0).getAmount());
        assertEquals(15.0, report.get(0).getBalance());

        assertEquals(5.0, report.get(1).getAmount());
        assertEquals(20.0, report.get(1).getBalance());

        verify(accountRepository).findAll();

        verify(transactionRepository)
                .findByAccountIdAndDateBetweenOrderByDateAscIdAsc(
                        eq(accountId),
                        any(Date.class),
                        any(Date.class));
    }
}
