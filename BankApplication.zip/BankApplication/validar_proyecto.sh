
#!/bin/bash

set -e

echo "=================================="
echo " VALIDANDO MICROSERVICIO ACCOUNT"
echo "=================================="

mvn -f account/pom.xml clean test -Dspring.profiles.active=test

echo ""
echo "=================================="
echo " VALIDANDO MICROSERVICIO CLIENT"
echo "=================================="

mvn -f client/pom.xml clean test -Dspring.profiles.active=test

echo ""
echo "=================================="
echo " AMBOS MICROSERVICIOS APROBADOS"
echo "=================================="
