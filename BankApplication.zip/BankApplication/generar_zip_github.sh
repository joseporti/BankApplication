
#!/bin/bash

set -e

echo "======================================"
echo " GENERANDO ZIP OFICIAL PARA GITHUB"
echo "======================================"

cd /home/project/Microservices

# Eliminar ZIP anterior si existe
rm -f BankApplication.zip

# Generar ZIP con la estructura solicitada
zip -qr BankApplication.zip BankApplication/ \
    -x "*/target/*" \
       "*/.git/*" \
       "*/.idea/*" \
       "*/.vscode/*" \
       "*/entrega/*" \
       "*/BankApplication_Entrega*.zip" \
       "*/.env"

echo ""
echo "========== VERIFICANDO INTEGRIDAD =========="
unzip -t BankApplication.zip | tail -1

echo ""
echo "========== ARCHIVO GENERADO =========="
ls -lh BankApplication.zip

echo ""
echo "========== PROCESO FINALIZADO =========="
echo "Ubicacion: /home/project/Microservices/BankApplication.zip"
