# BankApplication - Microservicios bancarios

Aplicación bancaria desarrollada con Java y Spring Boot, con dos microservicios independientes: Client y Account.

## Estructura

client: administración de clientes.
account: administración de cuentas bancarias, transacciones y reportes.
Makefile: ejecución de pruebas de ejemplo.
xunitreport.xml: reporte generado por las pruebas.

## Tecnologías

- Java 11/Spring Boot 2.4.2/Maven/Spring Data JPA/H2 Database/JUnit 5/ Mockito

## Puertos Microservicio

Account 8000
Client 8001

## Funcionalidades

### Client

- Crear clientes.
- Consultar clientes.
- Actualizar información.
- Actualizar parcialmente.
- Eliminar clientes.

### Account

- Crear y administrar cuentas bancarias.
- Registrar depósitos y retiros.
- Calcular el saldo después de cada movimiento.
- Validar saldo insuficiente.
- Rechazar transacciones de importe cero.
- Rechazar transacciones en cuentas inactivas o inexistentes.
- Generar reportes bancarios por cliente y rango de fechas.

## Endpoints principales

| GET/ POST | `/api/clients` |
| GET/ PUT / PATCH / DELETE | `/api/clients/{id}` |
| GET/ POST | `/api/accounts` |
| GET/ PUT / PATCH / DELETE | `/api/accounts/{id}` |
| GET/ POST | `/api/transactions` |
| GET| `/api/transactions/{id}` |
| GET| `/api/transactions/clients/{clientId}/report` |

El endpoint de reporte recibe los parámetros `dateTransactionStart` y `dateTransactionEnd`, en formato `yyyy-MM-dd`.

## Ejecutar pruebas automáticas

Desde la carpeta `account`:

```bash
mvn clean test
```

Desde la carpeta `client`:

```bash
mvn clean test
```

Desde la carpeta principal `BankApplication`, ejecutar las pruebas de ejemplo:

```bash
make run
```

## Resultados verificados

- Account: 3 pruebas superadas.
- Client: 4 pruebas superadas.
- Total: 7 pruebas, sin fallos ni errores.

## Observaciones

El microservicio Account utiliza una base de datos H2 persistente durante la ejecución normal y una base de datos H2 en memoria para sus pruebas automáticas.
La comunicación entre Account y Client se configura mediante la propiedad `client.service.url`.
