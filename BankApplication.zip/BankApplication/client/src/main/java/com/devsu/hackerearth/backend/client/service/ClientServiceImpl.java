
package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	// Convertir entidad a DTO

	private ClientDto toDto(Client client) {

		return new ClientDto(
				client.getId(),
				client.getDni(),
				client.getName(),
				client.getPassword(),
				client.getGender(),
				client.getAge(),
				client.getAddress(),
				client.getPhone(),
				client.isActive());
	}

	// Buscar cliente por ID

	private Client getEntity(Long id) {

		return clientRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException(
						"Cliente no encontrado: " + id));
	}

	// Listar clientes

	@Override
	public List<ClientDto> getAll() {

		return clientRepository.findAll()
				.stream()
				.map(this::toDto)
				.collect(Collectors.toList());
	}

	// Consultar cliente

	@Override
	public ClientDto getById(Long id) {

		return toDto(getEntity(id));
	}

	// Crear cliente

	@Override
	@Transactional
	public ClientDto create(ClientDto dto) {

		Client client = new Client();

		client.setDni(dto.getDni());
		client.setName(dto.getName());
		client.setPassword(dto.getPassword());
		client.setGender(dto.getGender());
		client.setAge(dto.getAge());
		client.setAddress(dto.getAddress());
		client.setPhone(dto.getPhone());
		client.setActive(dto.isActive());

		return toDto(clientRepository.save(client));
	}

	// Actualizar cliente

	@Override
	@Transactional
	public ClientDto update(ClientDto dto) {

		Client client = getEntity(dto.getId());

		client.setDni(dto.getDni());
		client.setName(dto.getName());
		client.setPassword(dto.getPassword());
		client.setGender(dto.getGender());
		client.setAge(dto.getAge());
		client.setAddress(dto.getAddress());
		client.setPhone(dto.getPhone());
		client.setActive(dto.isActive());

		return toDto(clientRepository.save(client));
	}

	// Actualizacion parcial

	@Override
	@Transactional
	public ClientDto partialUpdate(
			Long id,
			PartialClientDto dto) {

		Client client = getEntity(id);

		client.setActive(dto.isActive());

		return toDto(clientRepository.save(client));
	}

	// Eliminar cliente

	@Override
	@Transactional
	public void deleteById(Long id) {

		Client client = getEntity(id);

		clientRepository.delete(client);
	}
}
