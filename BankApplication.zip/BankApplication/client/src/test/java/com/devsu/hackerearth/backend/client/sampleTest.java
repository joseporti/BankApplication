
package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.Person;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

public class sampleTest {

        private ClientService clientService = mock(ClientService.class);
        private ClientController clientController = new ClientController(clientService);

        // Prueba 1: Crear cliente desde el controlador
        @Test
        void createClientTest() {
                // Arrange
                ClientDto newClient = new ClientDto(
                                1L, "1723456789", "Jose Portilla", "Password", "Masculino", 33, "Quito", "0999999999",
                                true);

                when(clientService.create(newClient)).thenReturn(newClient);
                // Act
                ResponseEntity<ClientDto> response = clientController.create(newClient);

                // Assert
                assertEquals(HttpStatus.CREATED, response.getStatusCode());
                assertEquals(newClient, response.getBody());
                verify(clientService, times(1)).create(newClient);
        }

        // Prueba 2: Validar entidad Client y herencia Person

        @Test
        void clientEntityTest() {

                // Arrange
                Client client = new Client();

                client.setId(1L);
                client.setDni("1723456789");
                client.setName("Jose Portilla");
                client.setPassword("Password");
                client.setGender("Masculino");
                client.setAge(33);
                client.setAddress("Quito");
                client.setPhone("0999999999");
                client.setActive(true);

                // Assert
                assertTrue(client instanceof Person);

                assertEquals(1L, client.getId());
                assertEquals("1723456789", client.getDni());
                assertEquals("Jose Portilla", client.getName());
                assertEquals("Password", client.getPassword());
                assertEquals("Masculino", client.getGender());
                assertEquals(33, client.getAge());
                assertEquals("Quito", client.getAddress());
                assertEquals("0999999999", client.getPhone());

                assertTrue(client.isActive());
        }

        // Prueba 3: Consultar cliente por ID

        @Test
        void getClientByIdTest() {

                ClientDto client = new ClientDto(
                                1L,
                                "1723456789",
                                "Jose Portilla",
                                "Password",
                                "Masculino", 33, "Quito",
                                "0999999999", true);

                when(clientService.getById(1L)).thenReturn(client);

                ResponseEntity<ClientDto> response = clientController.get(1L);
                assertEquals(HttpStatus.OK, response.getStatusCode());
                assertEquals(client, response.getBody());
                verify(clientService, times(1)).getById(1L);
        }

        @Test
        void diagnosticoUpdateClientTest() {

                ClientDto dto = new ClientDto(
                                1L,
                                "1723456789",
                                "Jose Portilla",
                                "Password",
                                "Masculino",
                                33,
                                "Quito",
                                "0999999999",
                                true);

                when(clientService.update(dto)).thenReturn(dto);

                ResponseEntity<ClientDto> response = clientController.update(1L, dto);

                assertEquals(HttpStatus.OK, response.getStatusCode());
                assertEquals(dto, response.getBody());

                verify(clientService, times(1)).update(dto);
        }

        @Test
        void diagnosticoUpdateClientIdDiferenteTest() {

                ClientDto dto = new ClientDto(
                                1L,
                                "1723456789",
                                "Jose Portilla",
                                "Password",
                                "Masculino",
                                33,
                                "Quito",
                                "0999999999",
                                true);

                when(clientService.update(dto)).thenReturn(dto);

                ResponseEntity<ClientDto> response = clientController.update(2L, dto);

                assertEquals(HttpStatus.OK, response.getStatusCode());
                assertEquals(dto, response.getBody());

                verify(clientService, times(1)).update(dto);
        }

}
