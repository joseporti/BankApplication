
#!/bin/bash

echo "======================================"
echo " VERIFICACION FINAL - BANK APPLICATION"
echo "======================================"

echo ""
echo "1. MICROSERVICIOS"
ls -ld account client

echo ""
echo "2. ARCHIVOS README"
find . -maxdepth 3 -iname "README*"

echo ""
echo "3. COLECCION POSTMAN"
find . -maxdepth 3 -iname "*postman*.json"

echo ""
echo "4. ARCHIVOS MAVEN"
find . -maxdepth 3 -name "pom.xml"

echo ""
echo "5. ARCHIVOS DE ENTREGA"
find . -maxdepth 2 \( -name "*.zip" -o -name ".gitignore" \)

echo ""
echo "6. ESTADO DE GIT"
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    git status --short
    git remote -v
else
    echo "Git todavia no esta configurado"
fi

echo ""
echo "======================================"
echo " VERIFICACION TERMINADA"
echo "======================================"
