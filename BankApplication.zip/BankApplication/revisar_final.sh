
#!/bin/bash

echo "========== ACCOUNT CONTROLLER =========="
sed -n '/@PutMapping/,/@PatchMapping/p' account/src/main/java/com/devsu/hackerearth/backend/account/controller/AccountController.java

echo ""
echo "========== CLIENT CONTROLLER =========="
sed -n '/@PutMapping/,/@PatchMapping/p' client/src/main/java/com/devsu/hackerearth/backend/client/controller/ClientController.java

echo ""
echo "========== TRANSACTION REPORT =========="
sed -n '/@GetMapping("\/clients\/{clientId}\/report")/,+22p' account/src/main/java/com/devsu/hackerearth/backend/account/controller/TransactionController.java
